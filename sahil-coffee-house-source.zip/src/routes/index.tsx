import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sahil Coffee — Bakıda qəhvəyə kiçik fasilə" },
      { name: "description", content: "Sahil Coffee-də təzə qəhvə, səhər yeməyi və sakit Bakı səhərləri." },
      { property: "og:title", content: "Sahil Coffee — Bakıda qəhvəyə kiçik fasilə" },
      { property: "og:description", content: "Yaxşı qəhvə, təzə bişmiş nəsə və səhərə ayılmaq üçün balaca bir səbəb." },
      { property: "og:type", content: "website" },
      { property: "og:image", content: "/coffee-og.svg" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CoffeeHome,
});

const coffeeItems = [
  { name: "Flat white", detail: "İkiqat espresso · ipək kimi süd", price: "8 ₼", tag: "ƏN SEVİLƏN" },
  { name: "V60", detail: "Mövsümi, tək mənşəli qəhvə", price: "10 ₼", tag: "YAVAŞ DƏMLƏMƏ" },
  { name: "Espresso tonic", detail: "Soyuq tonik · təzə espresso", price: "11 ₼", tag: "GÜNƏ TƏZƏLİK" },
];
const biteItems = [
  { name: "Badamlı kruassan", detail: "Kərə yağı ilə qat-qat, hər səhər təzə", price: "7 ₼", tag: "SƏHƏRİN SEÇİMİ" },
  { name: "Püstəli keks", detail: "Püstə kremi · limon qabığı", price: "8 ₼", tag: "EV ÜSULU" },
  { name: "Qranola kasası", detail: "Qatıq · bal · mövsümi meyvə", price: "9 ₼", tag: "YÜNGÜL" },
];

function Emblem({ small = false }: { small?: boolean }) {
  return <img className={small ? "brand-emblem brand-emblem-small" : "brand-emblem"} src="/sahil-emblem.svg" alt="" aria-hidden="true" />;
}

export function CoffeeHome() {
  const [menuTab, setMenuTab] = useState<"coffee" | "bites">("coffee");
  const items = menuTab === "coffee" ? coffeeItems : biteItems;

  return (
    <main className="coffee" id="top">
      <div className="c-topline"><span>BAKI · SAKİN SƏHƏRLƏR ÜÇÜN</span><span>HƏR GÜN <b>08:00 — 20:00</b></span></div>
      <header className="c-header">
        <a className="cbrand" href="#top" aria-label="Sahil Coffee ana səhifə"><Emblem /><span className="brand-name">sahil<span>coffee</span></span></a>
        <nav aria-label="Əsas menyu"><a href="#menu">Menyu</a><a href="#story">Haqqımızda</a><a href="#visit">Ünvan</a></nav>
        <a className="ccta" href="#visit">Bizi tap <span>↗</span></a>
      </header>

      <section className="c-hero" aria-labelledby="hero-title">
        <div className="c-hero-copy">
          <span className="eyebrow"><i /> QƏHVƏYƏ BALACA FASİLƏ</span>
          <h1 id="hero-title">Səhərin<br />öz <em>ritmi.</em></h1>
          <p>Yaxşı dəmlənmiş qəhvə, sobadan təzə çıxan kruassan və günə tələsmədən başlamaq üçün yer.</p>
          <div className="hero-actions"><a className="button-primary" href="#menu">Menyunu kəşf et <span>↓</span></a><a className="text-link" href="#story">Sahil haqqında <span>↗</span></a></div>
          <div className="hero-note"><div className="avatar-stack"><i>✳</i><i>☼</i><i>↗</i></div><span>Qəhvə ilə yavaşlayan<br />Bakı səhərləri</span></div>
        </div>
        <div className="c-hero-image">
          <img src="/images/hero.jpg" alt="Sahil Coffee-də günəş işığında qəhvə və kruassan" fetchPriority="high" />
          <div className="image-caption"><span>01 / SƏHƏR RİTUALI</span><span>YENİ DƏMLƏNİB</span></div>
          <div className="hero-stamp"><Emblem small /><span>QƏHVƏ<br />VƏ SAHİL</span></div>
        </div>
      </section>

      <div className="ticker" aria-label="Sahil Coffee haqqında"><span>YAXŞI QƏHVƏ</span><i>✳</i><span>YERLİ İSTİLİK</span><i>✳</i><span>TƏZƏ SƏHƏR</span><i>✳</i><span>YAXŞI QƏHVƏ</span><i>✳</i><span>YERLİ İSTİLİK</span></div>

      <section className="c-menu" id="menu">
        <div className="section-heading"><div><span className="eyebrow">BU GÜN BARDA</span><h2>Sadə şeylər.<br /><em>Yaxşı hazırlanmış.</em></h2></div><p>Menyumuz mövsümlə dəyişir. Sevdiyiniz klassiklər isə həmişə buradadır.</p></div>
        <div className="menu-layout">
          <div className="menu-feature">
            <img src={menuTab === "coffee" ? "/images/espresso.jpg" : "/images/pastry.jpg"} alt={menuTab === "coffee" ? "Mavi fincanda təzə espresso" : "Sahil Coffee-də kruassan, püstəli keks və kapuçino"} loading="lazy" />
            <span className="feature-label">{menuTab === "coffee" ? "BARİSTANIN SEÇİMİ" : "SOBADAN İNDİ ÇIXIB"}</span>
            <div className="feature-copy"><span>YAXŞI DƏNƏ · DƏQİQ DƏMLƏMƏ</span><b>{menuTab === "coffee" ? "Hər fincanda bir az diqqət." : "Bir tikə də səhərdən."}</b></div>
          </div>
          <div className="menu-list-wrap">
            <div className="menu-tabs" role="tablist" aria-label="Menyu kateqoriyası">
              <button role="tab" aria-selected={menuTab === "coffee"} className={menuTab === "coffee" ? "active" : ""} onClick={() => setMenuTab("coffee")}>Qəhvə <span>03</span></button>
              <button role="tab" aria-selected={menuTab === "bites"} className={menuTab === "bites" ? "active" : ""} onClick={() => setMenuTab("bites")}>Yüngül yemək <span>03</span></button>
            </div>
            <div className="menu-list" role="tabpanel">
              {items.map((item, i) => <article className="menu-row" key={item.name}><span className="row-number">0{i + 1}</span><div className="row-main"><span className="row-tag">{item.tag}</span><h3>{item.name}</h3><p>{item.detail}</p></div><b className="row-price">{item.price}</b></article>)}
            </div>
            <p className="menu-footnote">Bitki əsaslı süd seçimləri mövcuddur. <span>·</span> Qiymətlər konsept nümunəsidir.</p>
          </div>
        </div>
      </section>

      <section className="c-story" id="story">
        <div className="story-image"><img src="/images/interior.jpg" alt="Sahil Coffee-nin gün işığı ilə dolu sakit interyeri" loading="lazy" /><span className="story-number">02</span><span className="story-caption">PƏNCƏRƏ KƏNARINDA SƏHƏR</span></div>
        <div className="story-copy"><span className="eyebrow">BALACA QƏHVƏ EVİ</span><h2>Qəhvə fasiləsi<br /><em>bəhanə deyil.</em></h2><p>Sahil dostlarla görüşmək, tək oxumaq və ya sadəcə pəncərə kənarında oturmaq üçün sakit bir yerdir. Dənələri kiçik partiyalarla qovurur, hər fincanı sifarişdən sonra hazırlayırıq.</p><a href="#visit" className="text-link">Məkanımızı tap <span>↗</span></a><div className="story-signature"><Emblem small /><span>Yaxşı qəhvə, xoş söhbət.<br /><b>Sahil Coffee komandası</b></span></div></div>
      </section>

      <section className="photo-strip" aria-label="Sahil Coffee-dən anlar"><div className="photo-tile tile-wide"><img src="/images/table.jpg" alt="Mavi fincanda espresso və Bakı mənzərəsi" loading="lazy" /><span>ŞƏHƏR OYANARKƏN</span></div><div className="photo-tile"><img src="/images/pastry.jpg" alt="Kruassan və kapuçino ilə səhər süfrəsi" loading="lazy" /><span>HƏR SƏHƏR TƏZƏ</span></div><div className="photo-note"><span>☼</span><p>Tələsmə.<br />Qəhvən hələ <em>isti.</em></p><i>SAHİL · BAKI</i></div></section>

      <section className="c-visit" id="visit"><div className="visit-left"><span className="eyebrow">QAPI AÇIQDIR</span><h2>Görüşərik?</h2><p>Bir fincan qəhvə üçün yolunuzu bizə salın.</p><a className="button-light" href="https://maps.google.com/?q=Nizami+Street+Baku" target="_blank" rel="noreferrer">Xəritədə aç <span>↗</span></a></div><div className="visit-details"><div><span>ÜNVAN</span><p>Nizami küçəsi 42<br />Bakı, Azərbaycan</p></div><div><span>İŞ SAATLARI</span><p>Hər gün<br />08:00 — 20:00</p></div><div><span>QEYD</span><p>Bu portfel layihəsində<br />ünvan nümunə xarakterlidir.</p></div></div><div className="visit-orbit" aria-hidden="true"><Emblem small /></div></section>

      <footer className="c-footer"><a className="cbrand" href="#top"><Emblem /><span className="brand-name">sahil<span>coffee</span></span></a><span className="footer-location">Bakı · Azərbaycan</span><span className="footer-disclosure">AI ilə hazırlanmış vibe-coding portfel layihəsi · menyu və ünvan nümunədir.</span><a className="back-top" href="#top" aria-label="Yuxarı qayıt">↑</a></footer>
    </main>
  );
}
