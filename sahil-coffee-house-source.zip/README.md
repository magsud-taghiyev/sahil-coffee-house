# Sahil Coffee

**AI-assisted vibe-coding portfolio project.** This independent concept was created with AI assistance; it is not presented as a client commission or work completed solely by the portfolio owner.

A responsive, Azerbaijani-first café website concept for a fictional Baku coffee house, with original AI-generated café photography and a custom vector emblem.

## Features

- Responsive editorial landing page
- Interactive coffee and light-bites menu tabs
- Five original AI-generated photographs, optimized for the web
- Custom SVG emblem and matching favicon
- Subtle motion with reduced-motion support
- Accessible navigation, image descriptions, and focus states
- Map link for the sample location

## Technology

React 19, TypeScript, Vite, TanStack Start, and Cloudflare Workers static assets.

## Run locally

```sh
bun install
bun run dev
```

Build the standalone static React site with `bun run build:static`; the files are written to `static-dist/`. The full TanStack Start build is available with `bun run build`.

## Demo limitations

This is a visual portfolio concept. It has no authenticated admin panel, database, live booking, ordering, or payment system. Menu prices, address, opening hours, and other café details are illustrative and must be replaced with verified business information before real-world use.
