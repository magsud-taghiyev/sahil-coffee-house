import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { CoffeeHome } from "./routes/index";
import "./styles.css";

const root = document.getElementById("root");
if (!root) throw new Error("Missing app root");
createRoot(root).render(
  <StrictMode>
    <CoffeeHome />
  </StrictMode>,
);
